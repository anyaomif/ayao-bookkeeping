// This file is created by egg-ts-helper@2.1.1
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportProject = require('../../../app/controller/project');
import ExportRecord = require('../../../app/controller/record');
import ExportUpload = require('../../../app/controller/upload');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    project: ExportProject;
    record: ExportRecord;
    upload: ExportUpload;
    user: ExportUser;
  }
}
