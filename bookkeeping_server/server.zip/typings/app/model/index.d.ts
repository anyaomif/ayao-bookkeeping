// This file is created by egg-ts-helper@2.1.1
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportAppVersion = require('../../../app/model/app_version');
import ExportProject = require('../../../app/model/project');
import ExportRecord = require('../../../app/model/record');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    AppVersion: ReturnType<typeof ExportAppVersion>;
    Project: ReturnType<typeof ExportProject>;
    Record: ReturnType<typeof ExportRecord>;
    User: ReturnType<typeof ExportUser>;
  }
}
